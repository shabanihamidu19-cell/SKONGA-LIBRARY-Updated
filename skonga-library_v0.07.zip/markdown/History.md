# History

## Form I
- Theories of the origin of human beings
- Organisation and education in pre-colonial African societies
- Relations with the Middle East, Far East and Europe (1st–15th Century)

## Form II
- Colonial administrative systems in Africa
- Social services in colonial Africa
- Pre-nationalist movements in Africa

## Form III
- Nationalist movements in Africa
- Nation-building in Africa
- Africa’s participation in the United Nations

## Form IV
- Regional integration in Africa
- Africa’s role in international affairs
- Review of successes and challenges of nation-building